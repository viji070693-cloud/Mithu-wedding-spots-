import { motion } from 'motion/react';
import { Check, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const packages = [
  {
    name: "Silver Package",
    price: "Starting from ₹50,000",
    features: [
      "Wedding Hall Booking Support",
      "Basic Stage Decoration",
      "Entrance Floral Setup",
      "Standard Lighting",
      "On-site Coordinator"
    ],
    recommended: false
  },
  {
    name: "Gold Package",
    price: "Starting from ₹1,50,000",
    features: [
      "Premium Venue Selection",
      "Elegant Theme Decoration",
      "Full Hall Floral Setup",
      "Standard Catering (200 Guests)",
      "Basic Photography",
      "Music & Sound System"
    ],
    recommended: true
  },
  {
    name: "Platinum Package",
    price: "Starting from ₹3,00,000",
    features: [
      "Luxury Venue Booking",
      "Grand Custom Decoration",
      "Premium Catering (Unlimited)",
      "Professional Photography & Video",
      "Live Music / DJ Setup",
      "Full Wedding Planning Service"
    ],
    recommended: false
  }
];

export default function Packages() {
  return (
    <div className="pt-32 pb-24 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <span className="text-gold font-medium tracking-widest uppercase text-sm mb-4 block">Pricing</span>
          <h1 className="text-4xl md:text-6xl font-serif text-slate-900 mb-6">Wedding Packages</h1>
          <p className="text-slate-500 max-w-2xl mx-auto">
            Choose the perfect package that fits your dream and budget. All packages can be customized.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {packages.map((pkg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className={`relative bg-white p-10 rounded-3xl shadow-sm border ${
                pkg.recommended ? 'border-gold ring-2 ring-gold/20' : 'border-slate-100'
              }`}
            >
              {pkg.recommended && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gold text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
                  Recommended
                </div>
              )}
              <h3 className="text-2xl font-serif font-bold mb-2 text-slate-900">{pkg.name}</h3>
              <p className="text-gold font-bold text-lg mb-8">{pkg.price}</p>
              
              <ul className="space-y-4 mb-10">
                {pkg.features.map((feature, j) => (
                  <li key={j} className="flex items-start text-slate-600 text-sm">
                    <Check className="text-gold mr-3 shrink-0" size={18} />
                    {feature}
                  </li>
                ))}
              </ul>

              <Link
                to="/contact"
                className={`w-full py-4 rounded-full font-bold text-sm transition-all flex items-center justify-center ${
                  pkg.recommended 
                    ? 'bg-gold text-white hover:bg-gold/90 shadow-lg' 
                    : 'bg-slate-50 text-slate-900 hover:bg-slate-100'
                }`}
              >
                Enquire Now <ArrowRight className="ml-2" size={16} />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

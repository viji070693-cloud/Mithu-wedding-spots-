import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

export default function About() {
  return (
    <div className="pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-gold font-medium tracking-widest uppercase text-sm mb-4 block">Our Story</span>
            <h1 className="text-4xl md:text-6xl font-serif text-slate-900 mb-8 leading-tight">
              Crafting Unforgettable <br />
              <span className="italic">Wedding Experiences</span>
            </h1>
            <p className="text-slate-600 text-lg mb-6 leading-relaxed">
              Mithu's Wedding Spots was founded with a simple vision: to make every wedding as unique and beautiful as the couple celebrating it. With over 5 years of experience in the industry, we have become a trusted name in Tamil Nadu for wedding planning and venue management.
            </p>
            <p className="text-slate-600 text-lg mb-8 leading-relaxed">
              We understand that your wedding is more than just an event—it's a milestone. That's why we pour our heart and soul into every detail, from the grand stage decorations to the smallest floral arrangements.
            </p>

            <div className="space-y-4">
              {[
                "Trusted service with 200+ successful events",
                "Affordable packages for every budget",
                "Customized planning tailored to your traditions",
                "Dedicated team of experts for on-site management"
              ].map((item, i) => (
                <div key={i} className="flex items-center space-x-3">
                  <CheckCircle2 className="text-gold shrink-0" size={20} />
                  <span className="text-slate-700 font-medium">{item}</span>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80&w=1000"
                alt="Wedding Planning"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -left-10 bg-white p-8 rounded-3xl shadow-xl hidden md:block border border-gold/10">
              <p className="text-4xl font-serif font-bold text-gold mb-1">5+</p>
              <p className="text-sm text-slate-500 uppercase tracking-widest font-bold">Years of Excellence</p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

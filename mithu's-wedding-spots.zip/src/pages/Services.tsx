import { motion } from 'motion/react';
import { Building2, Sparkles, Utensils, Camera, Music, Flower2 } from 'lucide-react';

const services = [
  {
    icon: <Building2 size={32} />,
    title: "Wedding Hall Booking",
    desc: "We help you find and book the most premium and spacious wedding halls that suit your guest count and budget."
  },
  {
    icon: <Flower2 size={32} />,
    title: "Decoration",
    desc: "Exquisite stage decorations, entrance setups, and hall floral arrangements designed to match your theme."
  },
  {
    icon: <Utensils size={32} />,
    title: "Catering",
    desc: "A wide variety of delicious traditional and modern cuisines prepared with the highest quality standards."
  },
  {
    icon: <Camera size={32} />,
    title: "Photography",
    desc: "Professional photographers and videographers to capture every candid moment and grand celebration."
  },
  {
    icon: <Music size={32} />,
    title: "Music & DJ",
    desc: "Live music, traditional bands, and professional DJs to keep the energy high and the guests entertained."
  },
  {
    icon: <Sparkles size={32} />,
    title: "Lighting Setup",
    desc: "Atmospheric lighting that transforms the venue into a magical space for your evening celebrations."
  }
];

export default function Services() {
  return (
    <div className="pt-32 pb-24 bg-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <span className="text-gold font-medium tracking-widest uppercase text-sm mb-4 block">What We Offer</span>
          <h1 className="text-4xl md:text-6xl font-serif text-slate-900 mb-6">Our Premium Services</h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg">
            We provide comprehensive wedding solutions to ensure you can enjoy your special day without any stress.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-10 rounded-3xl shadow-sm hover:shadow-xl transition-all border border-gold/5 group"
            >
              <div className="w-16 h-16 bg-gold/10 text-gold rounded-2xl flex items-center justify-center mb-8 group-hover:bg-gold group-hover:text-white transition-colors">
                {service.icon}
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4 text-slate-900">{service.title}</h3>
              <p className="text-slate-500 leading-relaxed">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: "Anjali & Rahul",
    role: "Married in Jan 2024",
    text: "Mithu's Wedding Spots made our dream wedding a reality. The stage decoration was absolutely breathtaking and exactly what we discussed. Excellent service!",
    rating: 5
  },
  {
    name: "Suresh Kumar",
    role: "Father of the Bride",
    text: "The catering was the highlight of the event. Every guest praised the food quality and the professional service. Highly recommended for any family function.",
    rating: 5
  },
  {
    name: "Priya & Karthik",
    role: "Married in Nov 2023",
    text: "Very professional team. They handled everything from hall booking to photography seamlessly. We didn't have to worry about a single thing on our big day.",
    rating: 5
  },
  {
    name: "Meena Swaminathan",
    role: "Event Planner",
    text: "I've worked with many vendors, but Mithu's team is exceptionally dedicated. Their attention to detail in lighting and floral arrangements is unmatched.",
    rating: 5
  }
];

export default function Testimonials() {
  return (
    <div className="pt-32 pb-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <span className="text-gold font-medium tracking-widest uppercase text-sm mb-4 block">Reviews</span>
          <h1 className="text-4xl md:text-6xl font-serif text-slate-900 mb-6">What Our Clients Say</h1>
          <p className="text-slate-500 max-w-2xl mx-auto">
            Real stories from real couples who trusted us with their most precious moments.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-cream p-10 rounded-3xl border border-gold/5 relative"
            >
              <Quote className="absolute top-8 right-8 text-gold/10" size={64} />
              <div className="flex mb-6">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} size={18} className="text-gold fill-gold" />
                ))}
              </div>
              <p className="text-slate-700 text-lg italic mb-8 leading-relaxed relative z-10">
                "{t.text}"
              </p>
              <div>
                <h4 className="text-xl font-serif font-bold text-slate-900">{t.name}</h4>
                <p className="text-slate-500 text-sm uppercase tracking-widest">{t.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

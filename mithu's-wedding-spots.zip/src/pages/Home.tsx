import { motion } from 'motion/react';
import { ArrowRight, Star, Heart, Camera, Utensils, Music, Sparkles, Phone, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=2000"
            alt="Wedding Hall"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/40"></div>
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-serif text-white mb-6 leading-tight">
              Make Your Dream <br />
              <span className="italic text-gold">Wedding Come True</span> 💍
            </h1>
            <p className="text-lg md:text-xl text-white/90 mb-10 font-light tracking-wide max-w-2xl mx-auto">
              Luxury venues, exquisite decorations, and seamless planning for your most special day.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/contact"
                className="bg-gold text-white px-10 py-4 rounded-full text-lg font-medium hover:bg-gold/90 transition-all shadow-xl hover:scale-105 flex items-center"
              >
                Book Now <ArrowRight className="ml-2" size={20} />
              </Link>
              <Link
                to="/services"
                className="bg-white/10 backdrop-blur-md text-white border border-white/30 px-10 py-4 rounded-full text-lg font-medium hover:bg-white/20 transition-all"
              >
                Our Services
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Floating Quick Info */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 hidden md:flex items-center space-x-12 bg-white/90 backdrop-blur-sm px-12 py-6 rounded-2xl shadow-2xl border border-gold/20">
          <div className="flex items-center space-x-3">
            <div className="bg-gold/10 p-2 rounded-full text-gold"><Star size={20} /></div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Experience</p>
              <p className="text-sm font-semibold text-slate-800">5+ Years</p>
            </div>
          </div>
          <div className="h-8 w-px bg-slate-200"></div>
          <div className="flex items-center space-x-3">
            <div className="bg-gold/10 p-2 rounded-full text-gold"><Heart size={20} /></div>
            <div>
              <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Weddings</p>
              <p className="text-sm font-semibold text-slate-800">200+ Happy Couples</p>
            </div>
          </div>
          <div className="h-8 w-px bg-slate-200"></div>
          <div className="flex items-center space-x-3 text-gold font-serif font-bold italic">
            Mithu's Wedding Spots
          </div>
        </div>
      </section>

      {/* Highlights Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif text-slate-900 mb-4">Our Highlights</h2>
            <div className="w-24 h-1 bg-gold mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: <Sparkles />, title: "Best Venues", desc: "Handpicked premium wedding halls." },
              { icon: <Heart />, title: "Decorations", desc: "Elegant stage and hall setups." },
              { icon: <Utensils />, title: "Catering", desc: "Delicious multi-cuisine support." },
              { icon: <Camera />, title: "Photography", desc: "Capturing every precious moment." }
            ].map((item, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -10 }}
                className="p-8 bg-cream rounded-3xl border border-gold/10 text-center hover:shadow-xl transition-all"
              >
                <div className="w-16 h-16 bg-gold/10 text-gold rounded-2xl flex items-center justify-center mx-auto mb-6">
                  {item.icon}
                </div>
                <h3 className="text-xl font-serif font-bold mb-3">{item.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-soft-pink relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gold/5 rounded-full -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gold/5 rounded-full translate-y-1/2 -translate-x-1/2"></div>
        
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-serif text-slate-900 mb-8">Ready to start planning your big day?</h2>
          <p className="text-slate-600 mb-10 text-lg">Contact us today for a free consultation and customized package.</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <a href="tel:9514761822" className="flex items-center text-xl font-semibold text-slate-900 hover:text-gold transition-colors">
              <Phone className="mr-3 text-gold" /> 9514761822
            </a>
            <span className="hidden sm:inline text-slate-300">|</span>
            <a href="mailto:viji070693@gmail.com" className="flex items-center text-xl font-semibold text-slate-900 hover:text-gold transition-colors">
              <Mail className="mr-3 text-gold" /> viji070693@gmail.com
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

import { motion } from 'motion/react';
import { Phone, Mail, MapPin, Send, MessageSquare } from 'lucide-react';
import React, { useState } from 'react';

export default function Contact() {
  const [formState, setFormState] = useState({
    name: '',
    phone: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
    setFormState({ name: '', phone: '', message: '' });
  };

  return (
    <div className="pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <span className="text-gold font-medium tracking-widest uppercase text-sm mb-4 block">Get In Touch</span>
          <h1 className="text-4xl md:text-6xl font-serif text-slate-900 mb-6">Contact & Enquiry</h1>
          <p className="text-slate-500 max-w-2xl mx-auto">
            Have questions or ready to book? Fill out the form below or reach out to us directly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact Info */}
          <div className="lg:col-span-1 space-y-8">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gold/5">
              <div className="flex items-start space-x-4">
                <div className="bg-gold/10 p-3 rounded-2xl text-gold">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-serif font-bold mb-1">Call Us</h4>
                  <p className="text-slate-600">9514761822</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gold/5">
              <div className="flex items-start space-x-4">
                <div className="bg-gold/10 p-3 rounded-2xl text-gold">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-serif font-bold mb-1">Email Us</h4>
                  <p className="text-slate-600">viji070693@gmail.com</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gold/5">
              <div className="flex items-start space-x-4">
                <div className="bg-gold/10 p-3 rounded-2xl text-gold">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-serif font-bold mb-1">Location</h4>
                  <p className="text-slate-600">Tamil Nadu, India</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl">
              <h4 className="text-xl font-serif font-bold mb-4 text-gold italic">Quick Response</h4>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">
                We typically respond to all enquiries within 24 hours. For urgent bookings, please call us directly.
              </p>
              <a 
                href="https://wa.me/9514761822" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-full transition-all font-bold text-sm"
              >
                <MessageSquare className="mr-2" size={18} /> Chat on WhatsApp
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-10 md:p-12 rounded-[2.5rem] shadow-xl border border-gold/10"
            >
              <h3 className="text-3xl font-serif font-bold mb-8 text-slate-900">Send an Enquiry</h3>
              
              {submitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-emerald-50 text-emerald-700 p-8 rounded-3xl text-center border border-emerald-100"
                >
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Send size={32} />
                  </div>
                  <h4 className="text-xl font-bold mb-2">Message Sent Successfully!</h4>
                  <p>Thank you for reaching out. We will get back to you shortly.</p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Your Name</label>
                      <input
                        type="text"
                        required
                        value={formState.name}
                        onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                        placeholder="Enter your name"
                        className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-gold focus:ring-0 transition-all outline-none"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Phone Number</label>
                      <input
                        type="tel"
                        required
                        value={formState.phone}
                        onChange={(e) => setFormState({ ...formState, phone: e.target.value })}
                        placeholder="Enter your phone number"
                        className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-gold focus:ring-0 transition-all outline-none"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-slate-400 ml-1">Your Message</label>
                    <textarea
                      required
                      rows={5}
                      value={formState.message}
                      onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                      placeholder="Tell us about your wedding plans..."
                      className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-gold focus:ring-0 transition-all outline-none resize-none"
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-gold text-white py-5 rounded-2xl font-bold text-lg hover:bg-gold/90 transition-all shadow-lg hover:shadow-gold/20 flex items-center justify-center group"
                  >
                    Send Enquiry <Send className="ml-3 group-hover:translate-x-1 transition-transform" size={20} />
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

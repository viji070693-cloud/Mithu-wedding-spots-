import { Phone, Mail, Instagram, Facebook, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex flex-col items-start">
              <span className="text-3xl font-serif font-bold text-gold tracking-tight">Mithu's</span>
              <span className="text-xs uppercase tracking-[0.2em] text-slate-400 -mt-1">Wedding Spots</span>
            </Link>
            <p className="text-slate-400 text-sm leading-relaxed">
              Making your dream wedding come true with elegance and perfection. We specialize in creating unforgettable memories.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="#" className="text-slate-400 hover:text-gold transition-colors"><Instagram size={20} /></a>
              <a href="#" className="text-slate-400 hover:text-gold transition-colors"><Facebook size={20} /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-serif font-semibold mb-6 text-gold">Quick Links</h4>
            <ul className="space-y-3 text-sm text-slate-400">
              <li><Link to="/" className="hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/services" className="hover:text-white transition-colors">Services</Link></li>
              <li><Link to="/gallery" className="hover:text-white transition-colors">Gallery</Link></li>
              <li><Link to="/packages" className="hover:text-white transition-colors">Packages</Link></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-serif font-semibold mb-6 text-gold">Our Services</h4>
            <ul className="space-y-3 text-sm text-slate-400">
              <li>Wedding Hall Booking</li>
              <li>Stage Decoration</li>
              <li>Catering Support</li>
              <li>Photography & Video</li>
              <li>Music & DJ</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-serif font-semibold mb-6 text-gold">Contact Us</h4>
            <ul className="space-y-4 text-sm text-slate-400">
              <li className="flex items-start">
                <Phone size={18} className="mr-3 text-gold shrink-0" />
                <span>9514761822</span>
              </li>
              <li className="flex items-start">
                <Mail size={18} className="mr-3 text-gold shrink-0" />
                <span>viji070693@gmail.com</span>
              </li>
              <li className="flex items-start">
                <MapPin size={18} className="mr-3 text-gold shrink-0" />
                <span>Tamil Nadu, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 text-center text-xs text-slate-500">
          <p>&copy; {new Date().getFullYear()} Mithu's Wedding Spots. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
